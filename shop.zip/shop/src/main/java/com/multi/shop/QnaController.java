package com.multi.shop;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class QnaController {

	@Autowired
	QnaDAO dao;

	// 1. 고객
	// 1-1. 글작성
	@RequestMapping("insert01")
	public void insert01(QnaVO vo) {
		dao.insert01(vo);
	}

	// 1-2. 글수정
	@RequestMapping("update01")
	public void update01(QnaVO vo) {
		dao.update01(vo);
	}

	// 1-3. 글삭제 , 2-4. 게시판 삭제
	@RequestMapping("delete01")
	public void delete01(QnaVO vo) {
		dao.delete01(vo);
	}

	// 2. 관리자
	// 2-1. 댓글작성
	@RequestMapping("uqdate02")
	public void update02(QnaVO vo) {
		dao.update02(vo);
	}

	// 2-2. 댓글수정
	@RequestMapping("uqdate03")
	public void update03(QnaVO vo) {
		dao.update03(vo);
	}

	// 2-3. 댓글삭제
	@RequestMapping("uqdate04")
	public void update04(QnaVO vo) {
		dao.update04(vo);
	}

	// 3. 게시판 조회
	// 3-1. 게시판 전체 조회
	@RequestMapping("select01")
	public void select01(Model model) {
		List<QnaVO> list = dao.select01();
		model.addAttribute("list", list);
	}

	// 3-2. 특정 게시판 조회
	@RequestMapping("select02")
	public void select02(QnaVO vo, Model model) {
		QnaVO result = dao.select02(vo);
		model.addAttribute("vo", result);
	}

}
