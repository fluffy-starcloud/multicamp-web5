package com.multi.shop;

public class WareController {

}
