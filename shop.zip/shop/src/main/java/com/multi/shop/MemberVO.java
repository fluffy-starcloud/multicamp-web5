package com.multi.shop;

public class MemberVO {

}
