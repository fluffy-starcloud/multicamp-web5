package com.multi.shop;

public class WareDAO {

}
