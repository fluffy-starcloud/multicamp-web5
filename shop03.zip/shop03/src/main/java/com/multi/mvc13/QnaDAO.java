package com.multi.mvc13;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QnaDAO {

	@Autowired
	SqlSessionTemplate my;
	
	// 01. 게시글 작성
	public void insert(QnaVO vo) {
		my.insert("qna.insert", vo);
	}

	// 02. 게시글 상세보기
	public QnaVO view(QnaVO vo) {
		return my.selectOne("qna.view", vo);
	}

	// 03. 게시글 수정
	public void update(QnaVO vo) {
		my.update("qna.update", vo);
	}

	// 04. 게시글 삭제
	public void delete(QnaVO vo) {
		my.delete("qna.delete", vo);
	}

	// 05. 게시글 전체 목록
	public List<QnaVO> listAll() {
		return my.selectList("qna.listAll");
	}

	// 06. 게시글 조회 증가
	public void increaseViewcnt(int no) {
		my.update("qna.increaseViewcnt", no);
	}

}
