package com.multi.mvc13;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class QnaController {

	@Autowired
	QnaDAO dao;

	// 01. 게시글 목록
	@RequestMapping("list")
	public void all(Model model) {
		List<QnaVO> list = dao.listAll();
		model.addAttribute("list", list);

	}

	// 02-01. 게시글 작성화면
	// value = "", method = 전송방식
	@RequestMapping("write")
	public void insert(QnaVO vo) {
		dao.insert(vo);
	}

	/*
	 * // 02-02. 게시글 작성처리
	 * 
	 * @RequestMapping("insert.do") public String insert1(QnaVO vo) { return
	 * "redirect:list.do"; // list.do 다시 지시 }
	 */

	// 03. 게시글 상세내용 조회
	@RequestMapping("view")
	public void view(QnaVO vo, Model model) {
		QnaVO result = dao.view(vo);
		model.addAttribute("vo", result);
	}

	// 04. 게시글 수정
	@RequestMapping("update")
	public void update(QnaVO vo) {
		dao.update(vo);
	}

	// 05. 게시글 삭제
	@RequestMapping("delete")
	public void delete(QnaVO vo) {
		dao.delete(vo);
	}

}
