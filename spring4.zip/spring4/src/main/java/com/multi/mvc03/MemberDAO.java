package com.multi.mvc03;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MemberDAO {

	@Autowired
	SqlSessionTemplate my;

	// 회원 정보 검색
	public MemberVO one(MemberVO vo) {
		return my.selectOne("member.one01", vo);
	}

	// 회원 정보 조회
	public List<MemberVO> all() {
		return my.selectList("member.all");
	}

	// 회원 정보 추가
	public void insert(MemberVO vo) {
		my.insert("member.insert02", vo);
	}

	// 회원 정보 수정
	public void update(MemberVO vo) {
		my.update("member.update01", vo);
	}

	// 회원 정보 삭제
	public void delete(MemberVO vo) {
		my.delete("member.delete01", vo);
	}


}
