package com.multi.mvc03;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class JSONController2 {

	@Autowired
	MemberDAO dao;

	@RequestMapping("jsonMember")
	@ResponseBody
	public List<MemberVO> all() {
		List<MemberVO> list = dao.all();
		return list;
	}
	
}
