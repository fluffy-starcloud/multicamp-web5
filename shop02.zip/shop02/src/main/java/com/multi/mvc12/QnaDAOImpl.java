package com.multi.mvc12;

import java.util.List;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

// 인터페이스 구현 클래스
@Repository
public class QnaDAOImpl implements QnaDAO {

	@Inject
	SqlSessionTemplate my;
	
	// 01. 게시글 작성
	@Override
	public void create(QnaVO vo) throws Exception {
		my.insert("qna.insert", vo);
	}

	// 02. 게시글 상세보기
	@Override
	public Object read(int no) throws Exception {
		return my.selectCursor("qna.view", no);
	}

	// 03. 게시글 수정
	@Override
	public void update(QnaVO vo) throws Exception {
		my.update("qna.update", vo);
	}

	// 04. 게시글 삭제
	@Override
	public void delete(int no) throws Exception {
		my.delete("qna.delete", no);
	}

	// 05. 게시글 전체 목록
	@Override
	public List<QnaVO> listAll() throws Exception {
		return my.selectList("qna.listAll");
	}

	// 06. 게시글 조회 증가
	@Override
	public void increaseViewcnt(int no) throws Exception {
		my.update("qna.increaseViewcnt", no);
	}

}
