function go() {
	alert('집에 가자!')
}