package com.multi.mvc02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

@Component
public class GradeDAO {

	public void insert(GradeDTO bag) {
		System.out.println(bag);

		try {
			// 1. 드라이버 설정 - 드라이버(커넥터) 로딩.
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("1. 드라이버 설정 성공.");

			// 2. db 연결 mySQL : school, oracle : xe
			String url = "jdbc:mysql://localhost:3306/school";
			String user = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db 연결 성공.");

			// 3. sql문 만들기.
			String sql = "insert into grade values (null, ?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, bag.getClasses());
			ps.setString(2, bag.getName());
			ps.setString(3, bag.getGrade());
			System.out.println("3. sql문 생성 성공.");

			// 4. sql문을 db서버에 보내기.
			String result2 = "실패.";
			try {
				int result = ps.executeUpdate();
				System.out.println("4. sql문 db서버로 전송 성공.");
				if (result == 1) {
					result2 = "성공.";
				}
			} catch (Exception e) {
				System.out.println("성적정보 입력시 에러발생.");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} // insert

	public void delete(int id) {
		try {
			// 1. 드라이버 설정 - 드라이버(커넥터) 로딩.
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("1. 드라이버 설정 성공.");

			// 2. db 연결 mySQL : school, oracle : xe
			String url = "jdbc:mysql://localhost:3306/school";
			String user = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db 연결 성공.");

			// 3. sql문 만들기.
			String sql = "delete from grade where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			System.out.println("3. sql문 생성 성공.");

			// 4. sql문을 db서버에 보내기.
			String result2 = "실패.";
			try {
				int result = ps.executeUpdate();
				System.out.println("4. sql문 db서버로 전송 성공.");
				if (result == 1) {
					result2 = "성공.";
				}
			} catch (Exception e) {
				System.out.println("성적정보 입력시 에러발생.");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} // delete

	public GradeDTO one(int id) {
		GradeDTO bag = null;

		try {
			// 1. 드라이버 설정 - 드라이버(커넥터) 로딩.
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("1. 드라이버 설정 성공.");

			// 2. db 연결 mySQL : school, oracle : xe
			String url = "jdbc:mysql://localhost:3306/school";
			String user = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db 연결 성공.");

			// 3. sql문 만들기.
			String sql = "select * from grade where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			System.out.println("3. sql문 생성 성공.");

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				System.out.println("검색 결과가 있음");
				bag = new GradeDTO();
				bag.setId(rs.getInt(1));
				bag.setClasses(rs.getString(2));
				bag.setName(rs.getString(3));
				bag.setGrade(rs.getString(4));
			}

			ps.close();
			con.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bag;
	} // one

	public ArrayList<GradeDTO> list() {
		ArrayList<GradeDTO> list = new ArrayList<>();

		try {
			// 1. 드라이버 설정 - 드라이버(커넥터) 로딩.
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("1. 드라이버 설정 성공.");

			// 2. db 연결 mySQL : school, oracle : xe
			String url = "jdbc:mysql://localhost:3306/school";
			String user = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db 연결 성공.");

			// 3. sql문 만들기.
			String sql = "select * from grade";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 생성 성공.");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				GradeDTO bag = new GradeDTO();
				bag.setId(rs.getInt(1));
				bag.setClasses(rs.getString(2));
				bag.setName(rs.getString(3));
				bag.setGrade(rs.getString(4));
				list.add(bag);
			}
			System.out.println("box(list)에 들어간 가방의 갯수>> " + list.size());

			ps.close();
			con.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	} // arraylist

} // class
