package com.multi.mvc02;

public class MovieDTO {

	private String movie;

	public String getMovie() {
		return movie;
	}

	public void setMovie(String movie) {
		this.movie = movie;
	}

	@Override
	public String toString() {
		return "MovieDTO [movie=" + movie + "]";
	}
	
}
