package com.multi.mvc03;

public class QnaVO {
	
	private String writer;
	private String title;
	private String content;
	private String answer;
	private int no;
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	
	@Override
	public String toString() {
		return "QnaVO [writer=" + writer + ", title=" + title + ", content=" + content + ", answer=" + answer + ", no="
				+ no + "]";
	}
	
}
