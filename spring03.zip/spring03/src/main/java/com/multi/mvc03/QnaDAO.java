package com.multi.mvc03;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QnaDAO {

	@Autowired
	SqlSessionTemplate shop;
	
	//1. 고객
	//1-1. 글작성
	public void insert01(QnaVO vo) {
		shop.insert("qna.insert01", vo);
	}
	//1-2. 글수정
	public void update01(QnaVO vo) {
		shop.update("qna.update01", vo);
	}
	//1-3. 글삭제 , 2-4. 게시판 삭제
	public void delete01(QnaVO vo) {
		shop.delete("qna.delete01", vo);
	}
	
	//2. 관리자
	//2-1. 댓글작성
	public void update02(QnaVO vo) {
		shop.update("qna.update02", vo);
	}
	//2-2. 댓글수정
	public void update03(QnaVO vo) {
		shop.update("qna.update03", vo);
	}
	//2-3. 댓글삭제
	public void update04(QnaVO vo) {
		shop.update("qna.update04", vo);
	}
	
	//3. 게시판 조회
	//3-1. 게시판 전체 조회
	public List<QnaVO> select01() {
		return shop.selectList("qna.select01");
	}
	//3-2. 특정 게시판 조회
	public QnaVO select02(QnaVO vo) {
		return shop.selectOne("qna.select02", vo);
	}
	
	
}
