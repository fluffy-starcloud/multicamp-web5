package com.multi.www00;

public class One2Main {

	public static void main(String[] args) {

		One2 o1 = One2.getInstance();
		System.out.println(o1);
		System.out.println(One2.count);

		One2 o2 = One2.getInstance();
		System.out.println(o2);
		System.out.println(One2.count);
		
	}

}
