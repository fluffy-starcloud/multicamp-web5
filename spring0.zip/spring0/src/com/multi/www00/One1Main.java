package com.multi.www00;

public class One1Main {

	public static void main(String[] args) {
		
		One1 o1 = new One1();
		System.out.println(o1);
		One1 o2 = new One1();
		System.out.println(o2);
		
	}

}
