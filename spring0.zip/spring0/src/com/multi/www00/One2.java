package com.multi.www00;

public class One2 {

	static int count;
	static One2 object;

	public static One2 getInstance() {
		if (object == null) {
			object = new One2();
		}
		return object;
	}
	
	private One2() {
		System.out.println("객체 하나 생성됨.");
		count++;
	}
	
}
