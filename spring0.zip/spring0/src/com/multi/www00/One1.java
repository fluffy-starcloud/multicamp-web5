package com.multi.www00;

public class One1 {
	
	static int count;
	
	public One1() {
		System.out.println("객체 하나 생성됨.");
		count++;
	}
	
}
